export const img: string;
export const aboutustext: string;
export const missionText: string;
export const imageColor: string;
export const container: string;
export const table: string;
export const card: string;
export const card-text: string;